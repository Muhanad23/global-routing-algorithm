cd run/;
./iccad19gr -lef ../toys/iccad2019c/ispd18_sample/ispd18_test1.input.lef -def ../toys/iccad2019c/ispd18_sample/ispd18_test1.input.def -output ispd18_test1.solution.guide -threads 20;
cd ..;